﻿// CClientSocket.cpp: 구현 파일
//

#include "pch.h"
#include "Mafia_Liar_Client.h"
#include "CClientSocket.h"


// CClientSocket

CClientSocket::CClientSocket()
{
    RoomMaker = 0;
}

CClientSocket::~CClientSocket()
{
}


// CClientSocket 멤버 함수


void CClientSocket::SetWnd(HWND hWnd)
{
    m_hWnd = hWnd;//핸들 함수 설정
}

void CClientSocket::OnReceive(int nErrorCode)//서버에서 보낸 데이터 받기
{
    // TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
    TCHAR szBuffer[1024];
    ZeroMemory(szBuffer, sizeof(szBuffer));

    //szBuffer에 strTmp.Format(_T("[%s : %d]: %s"), strIPAddress, uPortNumber, strBuffer) 저장
    if (Receive(szBuffer, sizeof(szBuffer)) > 0) {
        CString strTmp = _T("");
        strTmp.Format(_T("%s"), szBuffer);
        SendMessage(m_hWnd, WM_CLIENT_RECV, 0, (LPARAM)szBuffer);//View의 OnClientRecv에 전송
    }
    CSocket::OnReceive(nErrorCode);
}

void CClientSocket::OnClose(int nErrorCode)//끌때
{
    // TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
    ShutDown();
    Close();

    CSocket::OnClose(nErrorCode);

    AfxMessageBox(_T("ERROR:Disconnected from server!"));
    PostQuitMessage(0);
}