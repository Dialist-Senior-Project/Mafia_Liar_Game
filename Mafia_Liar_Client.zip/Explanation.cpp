﻿// Explanation.cpp: 구현 파일
//

#include "pch.h"
#include "Mafia_Liar_Client.h"
#include "Explanation.h"
#include "afxdialogex.h"

#include <Mmsystem.h>
#pragma comment(lib, "Winmm.lib")

// Explanation 대화 상자

IMPLEMENT_DYNAMIC(Explanation, CDialogEx)

Explanation::Explanation(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_Explanation, pParent)
{

}

Explanation::~Explanation()
{
}

void Explanation::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_list_explain);
	DDX_Control(pDX, IDC_BUTTON1, m_btn1);
}


BEGIN_MESSAGE_MAP(Explanation, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &Explanation::OnBnBack)
	ON_WM_CTLCOLOR()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


// Explanation 메시지 처리기


void Explanation::OnBnBack()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CDialogEx::OnCancel();
}


HBRUSH Explanation::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  여기서 DC의 특성을 변경합니다.
	int nCtlID = pWnd->GetDlgCtrlID();
	
	switch (nCtlID) {
	case IDC_LIST1:
		pDC->SetBkColor(RGB(20, 20, 20));
		pDC->SetTextColor(RGB(250, 250, 250));
		hbr = ::CreateSolidBrush(RGB(51, 51, 51));
		break;
	}
	// TODO:  기본값이 적당하지 않으면 다른 브러시를 반환합니다.
	return hbr;
}


BOOL Explanation::OnEraseBkgnd(CDC* pDC)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	CRect rc;

	GetClientRect(rc);

	pDC->FillSolidRect(rc, RGB(0, 0, 0));

	return TRUE;
	//return CDialogEx::OnEraseBkgnd(pDC);
}


BOOL Explanation::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  여기에 추가 초기화 작업을 추가합니다.

	m_list_explain.InsertString(-1, L"                                       [PAINTING-MAFIA 룰 설명]");
	m_list_explain.InsertString(-1, L"*********************************************************************");
	m_list_explain.InsertString(-1, L"1. [최소 인원] 최소 4명부터 게임을 즐길 수 있습니다.");
	m_list_explain.InsertString(-1, L"2. [랜덤 직업] 게임이 시작되면 랜덤으로 경찰, 의사, 시민(시민팀)");
	m_list_explain.InsertString(-1, L"                        그리고 마피아(마피아팀) 총 4개 중 하나의 직업이 부여됩니다.");
	m_list_explain.InsertString(-1, L"    -  기본 인원 : 경찰 1인, 의사 1인, 마피아 1-2인");
	m_list_explain.InsertString(-1, L"3. [제시어] 시민팀은 제시어를 전달받지만 마피아팀은 받을 수 없습니다.");
	m_list_explain.InsertString(-1, L"4. [낮과 밤] 낮에는 모든 플레이어가 대화를 나눌 수 있습니다.");
	m_list_explain.InsertString(-1, L"                    그러나 밤에는 마피아만이 서로 대화를 나눌 수 있습니다.");
	m_list_explain.InsertString(-1, L"5. [투표 및 페인팅] 투표로 선정된 1인의 플레이어는 제시어로 그림을 그려");
	m_list_explain.InsertString(-1, L"                                자신이 마피아가 아님을 입증할 수 있습니다.");
	m_list_explain.InsertString(-1, L"6. [최후의 투표] 대상 플레이어의 페인팅이 끝나면 나머지 플레이어는");
	m_list_explain.InsertString(-1, L"                            그가 마피아인지 시민인지를 최종적으로 판결하게 됩니다.");
	m_list_explain.InsertString(-1, L"7. [찬반 과반수] 찬반투표 결과에 따라 대상 플레이어의 처형이 결정됩니다.");
	m_list_explain.InsertString(-1, L"8. [승리 조건] 시민팀은 마피아를 모두 제거할 경우,");
	m_list_explain.InsertString(-1, L"                        마피아는 시민팀을 모두 제거할 경우 승리합니다.");


	m_btn1.LoadBitmaps(IDB_BACK1, IDB_BACK2, NULL, NULL);
	m_btn1.SizeToContent();

	return TRUE;  // return TRUE unless you set the focus to a control
				  // 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}
