﻿// GameStart.cpp: 구현 파일

#include "pch.h"
#include "Mafia_Liar_Client.h"
#include "GameStart.h"
#include "afxdialogex.h"
#include "Mafia_Liar_ClientDoc.h"
#include "Mafia_Liar_ClientView.h"

#include <Mmsystem.h>
#pragma comment(lib, "Winmm.lib")

// GameStart 대화 상자

IMPLEMENT_DYNAMIC(GameStart, CDialogEx)

GameStart::GameStart(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_GameStart, pParent)
{

}

GameStart::~GameStart()
{
}

void GameStart::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON1, m_btn1);
	DDX_Control(pDX, IDC_BUTTON2, m_btn2);
	DDX_Control(pDX, IDC_BUTTON3, m_btn3);
}


BEGIN_MESSAGE_MAP(GameStart, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &GameStart::OnBnGameStart)
	ON_BN_CLICKED(IDC_BUTTON2, &GameStart::OnBnOpenExplanation)
	ON_BN_CLICKED(IDC_BUTTON3, &GameStart::OnBnClose)
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


// GameStart 메시지 처리기


void GameStart::OnBnGameStart()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	gamestart = 1; 

	Profile dlg;
	if (IDOK == dlg.DoModal()) {
		p_item[0] = dlg.p_item[0];
		p_item[1] = dlg.p_item[1];
		p_item[2] = dlg.p_item[2];
		p_item[3] = dlg.p_item[3];
		//userIP = dlg.userIP;
		OnOK();
	}
//	CDialogEx::OnCancel();
}


void GameStart::OnBnOpenExplanation()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	Explanation dlg;
	dlg.DoModal();
}


void GameStart::OnBnClose()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	gamestart = 0;
	CDialogEx::OnCancel();
}


BOOL GameStart::OnEraseBkgnd(CDC* pDC)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	CClientDC dc(this);
	CImage m_background;

	m_background.Load(L"BG_main.PNG");
	m_background.Draw(dc, 0, 0);
	m_background.Destroy();

	return TRUE;
	//return CDialogEx::OnEraseBkgnd(pDC);
}


BOOL GameStart::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  여기에 추가 초기화 작업을 추가합니다.

	//m_btn1.Attach(((CBitmapButton*)GetDlgItem(IDC_BUTTON1))->m_hWnd);
	m_btn1.LoadBitmaps(IDB_START1, IDB_START2, NULL, NULL);
	m_btn1.SizeToContent();
	m_btn2.LoadBitmaps(IDB_EXPLAIN1, IDB_EXPLAIN2, NULL, NULL);
	m_btn2.SizeToContent();
	m_btn3.LoadBitmaps(IDB_CLOSE1, IDB_CLOSE2, NULL, NULL);
	m_btn3.SizeToContent();

	/*
	m_bmpEXPLAIN.LoadBitmap(IDB_EXPLAIN);
	m_btn2.SetBitmap(m_bmpEXPLAIN);
	m_bmpCLOSE.LoadBitmap(IDB_CLOSE);
	m_btn3.SetBitmap(m_bmpCLOSE);
	*/

	return TRUE;  // return TRUE unless you set the focus to a control
				  // 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}
