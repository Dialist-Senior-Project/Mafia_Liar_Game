﻿#pragma once
#include "CClientSocket.h"
#include "Explanation.h"
// GameStart 대화 상자

class GameStart : public CDialogEx
{
	DECLARE_DYNAMIC(GameStart)

public:
	GameStart(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~GameStart();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_GameStart };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnGameStart();
	afx_msg void OnBnOpenExplanation();
	afx_msg void OnBnClose();
	int gamestart;
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual BOOL OnInitDialog();
	CBitmapButton m_btn1;
	CBitmapButton m_btn2;
	CBitmapButton m_btn3;
	int p_item[4];
	CString userIP;
};
