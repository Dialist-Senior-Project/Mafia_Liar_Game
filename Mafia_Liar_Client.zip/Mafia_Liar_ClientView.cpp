﻿// Mafia_Liar_ClientView.cpp: CMafiaLiarClientView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "Mafia_Liar_Client.h"
#endif

#include "Mafia_Liar_ClientDoc.h"
#include "Mafia_Liar_ClientView.h"

#include <Mmsystem.h>
#pragma comment(lib, "Winmm.lib")

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define PORT 9999

// CMafiaLiarClientView

IMPLEMENT_DYNCREATE(CMafiaLiarClientView, CFormView)

BEGIN_MESSAGE_MAP(CMafiaLiarClientView, CFormView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CFormView::OnFilePrintPreview)
	ON_BN_CLICKED(IDC_BUTTON1, &CMafiaLiarClientView::OnBnClickedBtnSend)
	ON_MESSAGE(WM_CLIENT_RECV, &CMafiaLiarClientView::OnClientRecv)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BUTTON2, &CMafiaLiarClientView::OnBnClickedButtonP1)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON3, &CMafiaLiarClientView::OnBnClickedButtonP2)
	ON_BN_CLICKED(IDC_BUTTON11, &CMafiaLiarClientView::OnBnClickedButtonP3)
	ON_BN_CLICKED(IDC_BUTTON12, &CMafiaLiarClientView::OnBnClickedButtonP4)
	ON_BN_CLICKED(IDC_BUTTON13, &CMafiaLiarClientView::OnBnClickedButtonP5)
	ON_BN_CLICKED(IDC_BUTTON8, &CMafiaLiarClientView::OnBnClickedButtonP6)
	ON_BN_CLICKED(IDC_BUTTON14, &CMafiaLiarClientView::OnBnClickedButtonP7)
	ON_BN_CLICKED(IDC_BUTTON15, &CMafiaLiarClientView::OnBnClickedButtonP8)
	ON_BN_CLICKED(IDC_BUTTON16, &CMafiaLiarClientView::OnBnClickedStartGame)
	ON_BN_CLICKED(IDC_BUTTON17, &CMafiaLiarClientView::OnBnClickedBtnYES)
	ON_BN_CLICKED(IDC_BUTTON18, &CMafiaLiarClientView::OnBnClickedBtnNO)
END_MESSAGE_MAP()

// CMafiaLiarClientView 생성/소멸

CMafiaLiarClientView::CMafiaLiarClientView() noexcept
	: CFormView(IDD_MAFIA_LIAR_CLIENT_FORM)
{
	// TODO: 여기에 생성 코드를 추가합니다.

	cnt = -1;
	sec = 0;
	mouseon = 0;
	complete = _T("");
	win_right = 0, win_bottom = 0;
	usercolor = 7;
	drawuser = 0;
	drawstt = 0, drawnow = 0;
	drawstr = 1;

	//item[2] = 7; // 흰색
	for (int i = 0; i < 8; i++) {
		userPort[i] = L"";
		userClient[i] = L"";
		usernameprint[i] = 0;
		imageok[i] = 0;
		for (int k = 0; k < 4; k++) {
			item[i][k] = 0;
			tmp_item[k] = 0;
		}
	}
	c_count = 1;
	us_c = 0;
	profileOK = L"";
	mynum = 0;
	itemRev = L"";
	imagex[0] = 50; imagex[1] = 50; imagex[2] = 50; imagex[3] = 50; imagex[4] = 650; imagex[5] = 650; imagex[6] = 650; imagex[7] = 650;
	imagey[0] = 10;	imagey[1] = 112; imagey[2] = 214; imagey[3] = 317; imagey[4] = 10; imagey[5] = 112; imagey[6] = 214; imagey[7] = 317;

	userIP = _T("");
}

CMafiaLiarClientView::~CMafiaLiarClientView()
{
}

void CMafiaLiarClientView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_list_msg);
	DDX_Control(pDX, IDC_EDIT1, m_edit_send);

	DDX_Control(pDX, IDC_COMBO1, m_combo1);
	DDX_Control(pDX, IDC_COMBO2, m_combo2);
	DDX_Control(pDX, IDC_COMBO3, m_combo3);
	DDX_Control(pDX, IDC_COMBO4, m_combo4);
	DDX_Control(pDX, IDC_COMBO5, m_combo5);
	DDX_Control(pDX, IDC_COMBO6, m_combo6);
	DDX_Control(pDX, IDC_COMBO7, m_combo7);
	DDX_Control(pDX, IDC_COMBO8, m_combo8);
	DDX_Control(pDX, IDC_BUTTON1, m_submit);
	DDX_Control(pDX, IDC_BUTTON2, m_user1);
	DDX_Control(pDX, IDC_BUTTON3, m_user2);
	DDX_Control(pDX, IDC_BUTTON11, m_user3);
	DDX_Control(pDX, IDC_BUTTON12, m_user4);
	DDX_Control(pDX, IDC_BUTTON13, m_user5);
	DDX_Control(pDX, IDC_BUTTON8, m_user6);
	DDX_Control(pDX, IDC_BUTTON14, m_user7);
	DDX_Control(pDX, IDC_BUTTON15, m_user8);
	DDX_Control(pDX, IDC_BUTTON16, m_stt);
	DDX_Control(pDX, IDC_BUTTON17, m_yes);
	DDX_Control(pDX, IDC_BUTTON18, m_no);
}

BOOL CMafiaLiarClientView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.
	return CFormView::PreCreateWindow(cs);
	// TODO: 여기에 추가 초기화 작업을 추가합니다.

}

void CMafiaLiarClientView::OnInitialUpdate()
{
	GameStart dlg;
	if (IDOK == dlg.DoModal()) {
		if (dlg.gamestart) {
			tmp_item[0] = dlg.p_item[0];
			tmp_item[1] = dlg.p_item[1];
			tmp_item[2] = dlg.p_item[2];
			tmp_item[3] = dlg.p_item[3];
			//userIP = dlg.userIP;
			CFormView::OnInitialUpdate();
		}
	}
	else 
		AfxGetMainWnd()->PostMessage(WM_COMMAND, ID_APP_EXIT, 0);

	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	m_ClientSocket.SetWnd(this->m_hWnd);
	m_ClientSocket.Create();
	if (m_ClientSocket.Connect(_T("127.0.0.1"), PORT) == FALSE) {
		AfxMessageBox(_T("ERROR : Failed to connect Server"));
		PostQuitMessage(0);
	}

	m_combo1.AddString(L"  ?");
	m_combo1.AddString(L"경찰");
	m_combo1.AddString(L"의사");
	m_combo1.AddString(L"시민");
	m_combo1.AddString(L"마피아");
	m_combo1.SetCurSel(0);
	m_combo2.AddString(L"  ?");
	m_combo2.AddString(L"경찰");
	m_combo2.AddString(L"의사");
	m_combo2.AddString(L"시민");
	m_combo2.AddString(L"마피아");
	m_combo2.SetCurSel(0);
	m_combo3.AddString(L"  ?");
	m_combo3.AddString(L"경찰");
	m_combo3.AddString(L"의사");
	m_combo3.AddString(L"시민");
	m_combo3.AddString(L"마피아");
	m_combo3.SetCurSel(0);
	m_combo4.AddString(L"  ?");
	m_combo4.AddString(L"경찰");
	m_combo4.AddString(L"의사");
	m_combo4.AddString(L"시민");
	m_combo4.AddString(L"마피아");
	m_combo4.SetCurSel(0);
	m_combo5.AddString(L"  ?");
	m_combo5.AddString(L"경찰");
	m_combo5.AddString(L"의사");
	m_combo5.AddString(L"시민");
	m_combo5.AddString(L"마피아");
	m_combo5.SetCurSel(0);
	m_combo6.AddString(L"  ?");
	m_combo6.AddString(L"경찰");
	m_combo6.AddString(L"의사");
	m_combo6.AddString(L"시민");
	m_combo6.AddString(L"마피아");
	m_combo6.SetCurSel(0);
	m_combo7.AddString(L"  ?");
	m_combo7.AddString(L"경찰");
	m_combo7.AddString(L"의사");
	m_combo7.AddString(L"시민");
	m_combo7.AddString(L"마피아");
	m_combo7.SetCurSel(0);
	m_combo8.AddString(L"  ?");
	m_combo8.AddString(L"경찰");
	m_combo8.AddString(L"의사");
	m_combo8.AddString(L"시민");
	m_combo8.AddString(L"마피아");
	m_combo8.SetCurSel(0);
	for (int i = 0; i < 8; i++)
		username[i].Format(L"user%d", i + 1);
	
	GetDlgItem(IDC_STATIC2)->GetWindowRect(rc);
	ScreenToClient(rc);

	GetClientRect(rc2);

	m_submit.LoadBitmaps(IDB_SUBMIT1, IDB_SUBMIT2, NULL, NULL);
	m_submit.SizeToContent();

	m_user1.LoadBitmaps(IDB_USER1, IDB_USER1, NULL, NULL);
	m_user1.SizeToContent();
	m_user2.LoadBitmaps(IDB_USER2, IDB_USER2, NULL, NULL);
	m_user2.SizeToContent();
	m_user3.LoadBitmaps(IDB_USER3, IDB_USER3, NULL, NULL);
	m_user3.SizeToContent();
	m_user4.LoadBitmaps(IDB_USER4, IDB_USER4, NULL, NULL);
	m_user4.SizeToContent();
	m_user5.LoadBitmaps(IDB_USER5, IDB_USER5, NULL, NULL);
	m_user5.SizeToContent();
	m_user6.LoadBitmaps(IDB_USER6, IDB_USER6, NULL, NULL);
	m_user6.SizeToContent();
	m_user7.LoadBitmaps(IDB_USER7, IDB_USER7, NULL, NULL);
	m_user7.SizeToContent();
	m_user8.LoadBitmaps(IDB_USER8, IDB_USER8, NULL, NULL);
	m_user8.SizeToContent();

	m_yes.LoadBitmaps(IDB_YES, IDB_YES, NULL, NULL);
	m_yes.SizeToContent();
	m_no.LoadBitmaps(IDB_NO, IDB_NO, NULL, NULL);
	m_no.SizeToContent();
	m_stt.LoadBitmaps(IDB_START, IDB_START, NULL, NULL);
	m_stt.SizeToContent();

	//CString str2 = _T("_          ");
	//CString pq;
	//pq.Format(L"p%sp %d", str2, str2.GetLength());
	//AfxMessageBox(pq);

	for (int i = 0; i < 8; i++)
		role[i] = 0;

	out = L"";
	cwrd = L"???";
	mySel = selected  = -1;
	m_case = 0;
	death = false;
}


// CMafiaLiarClientView 인쇄

BOOL CMafiaLiarClientView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);

}
void CMafiaLiarClientView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CMafiaLiarClientView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}

void CMafiaLiarClientView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: 여기에 사용자 지정 인쇄 코드를 추가합니다.
}


// CMafiaLiarClientView 진단

#ifdef _DEBUG
void CMafiaLiarClientView::AssertValid() const
{
	CFormView::AssertValid();
}

void CMafiaLiarClientView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CMafiaLiarClientDoc* CMafiaLiarClientView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMafiaLiarClientDoc)));
	return (CMafiaLiarClientDoc*)m_pDocument;
}
#endif //_DEBUG


// CMafiaLiarClientView 메시지 처리기

#define nnn 47
void CMafiaLiarClientView::OnBnClickedBtnSend()//전송 버튼
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);

	if (!drawuser) { // 스케치 중일 때는 침묵 모드
		CString str = _T(""), str2 = _T(""), str3 = _T("_        ");
		int nn = nnn - 8 - username[mynum].GetLength();

		for (int i = 0; i < username[mynum].GetLength(); i++) {
			str3 = str3 + L" ";
		}

		UpdateData(TRUE);
		m_edit_send.GetWindowTextW(str);//입력칸에 입력한 데이터 가져오기

		if (str.Trim() == "") {
			return;
		}
		else if (str.GetLength() > 100) {
			AfxMessageBox(L"글자 수 제한 100");
			m_edit_send.SetWindowTextW(str.Left(100));
			return;
		}
		else if (str.Find(';') != -1 || str.Find('_') != -1 || str.Find('$') != -1) {
			AfxMessageBox(L"사용불가능한 문자(;, _, $)가 포함돼 있습니다.");
			m_edit_send.SetWindowTextW(_T(""));//입력칸 초기화
			return;
		}
		//LPVOID=void*

		int cntstr = str.GetLength() / nn;
		int remstr = str.GetLength() % nn;

		if (cntstr == 0 || (cntstr == 1 && remstr == 0)) {
			str = str + _T("_");
		}
		else {
			for (int i = 0; i < cntstr; i++) {
				str2 = str2 + str.Mid(i * nn, nn);
				str2 = str2 + str3;
			}
			str2 = str2 + str.Right(remstr);
			str = str2 + _T("_");
		}

		str.Format(L"채팅%s;;", (LPCTSTR)str);
		m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);//서버로 데이터 보내기
		m_edit_send.SetWindowTextW(_T(""));//입력칸 초기화
		UpdateData(FALSE);
	}
}


afx_msg LRESULT CMafiaLiarClientView::OnClientRecv(WPARAM wParam, LPARAM lParam)
{
	LPCTSTR lpszStr = (LPCTSTR)lParam;

	CString str, str2, check;
	str.Format(L"%s", lpszStr);
	check = str.Left(2);

	if (check == "좌표") {
		str = str.Right(str.GetLength() - 2);
		int x = _ttoi(str) / 10000;
		int y = _ttoi(str) % 10000;

		++cnt;
		pt[cnt] = CPoint(x, y);

		
		if (drawuser != mynum) {
			drawnow = (float)timeGetTime() * 0.001f;
			if (drawnow - drawstt >= 0.2f) {
				InvalidateRect(rc);
				
				drawstt = (float)timeGetTime() * 0.001f;
			}
			
		}
		//complete.Format(L"(%d, %d)", x, y);
		//*/
	}

	else if (check == "마감") {
		KillTimer(0);
		int draw = drawuser;
		drawuser = 0; // 스케치 종료
		complete.Format(L"[%s]: 어때요? 나 시민 맞죠?", (LPCTSTR)username[draw - 1]);

		InvalidateRect(rc);
		//sec = 8;
		sec = 2;
		SetTimer(1, 1000, NULL);
		//m_case = 4;
		//m_time = 3;
	}

	else if (check == "채팅") {
		if (!death) {
			str = str.Right(str.GetLength() - 2);
			CString userID, talk, userclient, usercount, profileOK, item_all;

			AfxExtractSubString(userID, str, 0, ';');//Portnum
			AfxExtractSubString(talk, str, 1, ';');//대화
			AfxExtractSubString(userclient, str, 2, ';');//클라이언트 번호
			AfxExtractSubString(usercount, str, 3, ';');//인원
			AfxExtractSubString(profileOK, str, 4, ';');//프로필 바꿔도 됨??
			AfxExtractSubString(item_all, str, 5, ';');

			if (userID == L"" && userclient != L"") {
				str2.Format(L"___________________[user%s]님 입장하였습니다.___________________", (LPCTSTR)usercount);
				if (mynum == 0)
					mynum = _ttoi(usercount);

				/*if (mynum == 1) {
					GetDlgItem(IDC_BUTTON16)->ModifyStyle(0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);
					GetDlgItem(IDC_LIST1)->ModifyStyle(0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);
					GetDlgItem(IDC_BUTTON16)->BringWindowToTop();
					GetDlgItem(IDC_BUTTON16)->EnableWindow(TRUE);
					GetDlgItem(IDC_BUTTON16)->ShowWindow(SW_SHOW);
				}*/
				ctrlButton(0, mynum);  //##### 주석 해제할것 !

				CString user_item, item_tmp, who_tmp;
				int who_tmp_i;
				for (int i = 0; i < 8; i++) {
					AfxExtractSubString(user_item, item_all, i, '$');
					if (user_item != L"") {
						AfxExtractSubString(who_tmp, user_item, 0, '_');
						who_tmp_i = _ttoi(who_tmp);
						for (int k = 0; k < 4; k++) {
							AfxExtractSubString(item_tmp, user_item, k + 1, '_');
							item[who_tmp_i][k] = _ttoi(item_tmp);
						}
					}
					else
						break;
				}
				m_list_msg.InsertString(-1, str2);
				m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
				str.Format(L"채팅;%s;;;%d_%d_%d_%d", (LPCTSTR)userclient, tmp_item[0], tmp_item[1], tmp_item[2], tmp_item[3]);
				m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);
			}

			if (talk != L"") {
				int cntstr = str.GetLength() / nnn;
				int remstr = str.GetLength() % nnn;

				if (cntstr == 0 || (cntstr == 1 && remstr == 0)) {
					AfxExtractSubString(str, talk, 0, '_');

					m_list_msg.InsertString(-1, str);
					m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
				}
				else {
					for (int i = 0; i <= cntstr; i++) {
						AfxExtractSubString(str, talk, i, '_');

						m_list_msg.InsertString(-1, str);
						m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
					}
				}
			}
			if (usercount != L"")
				us_c = _ttoi(usercount);
		}
	}


	else if (check == "연재") {
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_LIST1)->ShowWindow(SW_HIDE);
		str = str.Right(str.GetLength() - 2);
		drawuser = _ttoi(str.Left(1)); // 스케치 시작
		usercolor = _ttoi(str.Right(1));
		complete.Format(L"\n[%s]님이 그리고 있습니다.                                                   (한붓그리기)", (LPCTSTR)username[drawuser - 1]);

		drawstt = (float)timeGetTime() * 0.001f;

		InvalidateRect(rc);
		drawstr = 0;
		//sec = 15;
		sec = 5;
		SetTimer(0, 1000, NULL);
	}

	else if (check == "역할") {
		str = str.Right(str.GetLength() - 2);
		CString h, p, m1, m2;

		//MessageBox(str, L"역할");
		AfxExtractSubString(h, str, 0, ';');
		AfxExtractSubString(p, str, 1, ';');
		AfxExtractSubString(m1, str, 2, ';');
		AfxExtractSubString(cwrd, str, 3, ';');
		//str.Format(L"h=" + h + L", p=" + p + L", m1=" + m1 + L", wd=" + cwrd);
		//MessageBox(str, L"자른뒤");

		if (mynum - 1 == _ttoi(h)) {
			role[mynum - 1] = 11;
			out.Format(L"당신은 [의사] 입니다");
		}
		else if (mynum - 1 == _ttoi(p)) {
			role[mynum - 1] = 22;
			out.Format(L"당신은 [경찰] 입니다");
		}
		else if (mynum - 1 == _ttoi(m1)) {   //+ 1) || (mynum == _ttoi(m2) + 1)) {
			role[mynum - 1] = 33;
			out.Format(L"당신은 [마피아] 입니다");
		}
		else {
			role[mynum - 1] = 44;
			out.Format(L"당신은 [시민] 입니다");
		}

		//CString tmp;
		//tmp.Format(L"role[mynum]:%d", role[mynum]);
		//MessageBox(tmp, L"역할");

		//MessageBox(out, L"");
//		GetDlgItem(IDC_EDIT8)->EnableWindow(TRUE); // 버튼 활성화
//		SetDlgItemText(IDC_EDIT8, out + L".");
//		GetDlgItem(IDC_EDIT8)->ShowWindow(SW_SHOW); // 버튼 공개
//		SetTimer(2, 2000, NULL);

		SetDlgItemText(IDC_STATIC3, out);


		//CString tmp;
		//tmp.Format(L"role[mynum] : %d", role[mynum]);
		//MessageBox(cwrd, L"제시");

		if (role[mynum - 1] != 33) {    // != L"mfa"  //안됨
//			GetDlgItem(IDC_EDIT8)->EnableWindow(TRUE);
//			SetDlgItemText(IDC_EDIT8, L"제시어 : " + cwrd);
//			GetDlgItem(IDC_EDIT8)->ShowWindow(SW_SHOW);
//			SetTimer(3, 2000, NULL);
			SetDlgItemText(IDC_STATIC4, L"제시어 : " + cwrd);
		}
	}

	else if (check == "공개") {
		str = str.Right(str.GetLength() - 3);
		m_list_msg.AddString(str);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);

		SetDlgItemText(IDC_STATIC, L"서바이벌을 시작합니다");
		GetDlgItem(IDC_STATIC)->ShowWindow(SW_SHOW);

		/*GetDlgItem(IDC_STATIC3)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC4)->ShowWindow(SW_SHOW);

		//GetDlgItem(IDC_EDIT6)->EnableWindow(TRUE);IDC_STATIC
		SetDlgItemText(IDC_EDIT6, L"제시어 : " + cwrd);IDC_STATIC
		GetDlgItem(IDC_EDIT6)->ShowWindow(SW_SHOW);IDC_STATIC
		//GetDlgItem(IDC_EDIT7)->EnableWindow(TRUE);
		SetDlgItemText(IDC_EDIT7, out);
		GetDlgItem(IDC_EDIT7)->ShowWindow(SW_SHOW);*/
		/*GetDlgItem(IDC_EDIT6)->ModifyStyle(0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);  //스타일 설정 ?IDC_STATIC
		GetDlgItem(IDC_EDIT7)->ModifyStyle(0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);  //스타일 설정 ?
		GetDlgItem(IDC_LIST1)->ModifyStyle(0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);
		GetDlgItem(IDC_EDIT6)->BringWindowToTop();  //가장 상위에 위치 시킬 컨트롤IDC_STATIC
		GetDlgItem(IDC_EDIT7)->BringWindowToTop();  //가장 상위에 위치 시킬 컨트롤*/
		SetTimer(3, 2000, NULL);  //2->3 ok
	}


	/*else if (check == "허용") {
		allowed = true;
		//GetDlgItem(IDC_EDIT1)->EnableWindow(TRUE);
		MessageBox(L"허용2", L"");
	}
	else if (check == "차단") {
		GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);
	}*/
	//else if (check == "일몰") {}

	else if (check == "지령") {
		if (!death) {

			str = str.Right(str.GetLength() - 2);
			int c = _ttoi(str.Left(2));
			str = str.Right(str.GetLength() - 2);

			if (c == role[mynum - 1]) {
				m_list_msg.InsertString(-1, str);
				m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
			}
		}
	}


	else if (check == "대화") {  //임시 분리
		if (!death) {
			str = str.Right(str.GetLength() - 3);
			m_time = _ttoi(str.Left(2));
			str = str.Right(str.GetLength() - 3);

			GetDlgItem(IDC_EDIT1)->EnableWindow(TRUE);  //채팅 허용
			//낮 이미지
			m_list_msg.InsertString(-1, str);
			m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
			m_case = 1;
			SetTimer(4, 1000, NULL);
		}
	}

	else if (check == "시작") {  //시간 제한
		if (!death) {

			str = str.Right(str.GetLength() - 3);
			check = str.Left(2);
			str = str.Right(str.GetLength() - 3);
			m_time = _ttoi(str.Left(2));
			str = str.Right(str.GetLength() - 3);

			//m_list_msg.InsertString(-1, str);
			//m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);

			/*if (check == "대화") {

				GetDlgItem(IDC_EDIT1)->EnableWindow(TRUE);  //채팅 허용
				//낮 이미지
				m_list_msg.InsertString(-1, str);
				m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
				//tover = L"";
				SetTimer(4, 1000, NULL);
			}*/

			//else if (check == "일몰") {
			if (check == "일몰") {

				//밤 이미지
				m_list_msg.InsertString(-1, str);
				m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
				GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE); //채팅 불허


				CString tmp;
				if (role[mynum - 1] == 11) {
					tmp.Format(L"  <지령>  대상 1인을 지정해 [마피아]로부터 보호하십시오.");
					//m_list_msg.InsertString(-1, tmp);
					//m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
					enableAllSel();
				}
				else if (role[mynum - 1] == 22) {
					tmp.Format(L"  <지령>  대상 1인을 지정해 그가 [마피아]인지 확인하십시오.");
					enableAllSel();
				}
				else if (role[mynum - 1] == 33) {
					tmp.Format(L"  <지령>  대상 1인을 지목해 살해하십시오.");
					enableAllSel();
				}
				else {  //(role[mynum] == 44)
					tmp.Format(L" 일출까지 대기하십시오.");
				}
				m_list_msg.InsertString(-1, tmp);
				m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
				//tover = L"일몰";
				m_case = 2;
				//SetTimer(5, 1000, NULL);
				SetTimer(4, 1000, NULL);
			}
			//m_time = t;
			//SetTimer(4, 1000, NULL);
		}
	}


	else if (check == "사망") {
		str = str.Right(str.GetLength() - 2);
		CString sound = str.Left(1);
		str = str.Right(str.GetLength() - 1);
		int n = _ttoi(str.Left(1));
		str = str.Right(str.GetLength() - 1);
		m_list_msg.AddString(str);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
		//MessageBox(L"사망", L"");

		if (sound == "총") {
			PlaySound(L"wav\\BGM_GUN.wav", NULL, SND_ASYNC); // 무한
		}

		if (n == (mynum - 1)) {
			death = true;  //투표불가, 타이머진행불가
			CString tmp(L"당신은 사망했습니다.");
			GetDlgItem(IDC_STATIC_DTH)->SetWindowTextW(tmp);
			GetDlgItem(IDC_STATIC_DTH)->ModifyStyle(0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);  //스타일 설정 ?
			GetDlgItem(IDC_LIST1)->ModifyStyle(0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);
			GetDlgItem(IDC_STATIC_DTH)->BringWindowToTop();  //가장 상위에 위치 시킬 컨트롤
			GetDlgItem(IDC_STATIC_DTH)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);  //채팅불가
		}		
		
	}


	else if (check == "투표") {
		if (!death) {
			str = str.Right(str.GetLength() - 3);
			m_time = _ttoi(str.Left(2));
			str = str.Right(str.GetLength() - 3);
			m_list_msg.AddString(str);
			m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);

			//if (role[mynum - 1] != 33) {
				enableAllSel();
				//m_case = 3;
				SetTimer(4, 1000, NULL);
			//}
		}
	}


	else if (check == "그림") {
		CString tmp;
		str = str.Right(str.GetLength() - 3);
		selected = _ttoi(str.Left(1));

		if (mynum - 1 == selected) {
			SetDlgItemText(IDC_STATIC, L"당신은 최다 득표자 입니다. 당신의 결백을 증명하십시오.");
			GetDlgItem(IDC_STATIC)->ShowWindow(SW_SHOW);
			SetTimer(5, 3000, NULL);
			//SetTimer(4, 2000, NULL);
		}

		str = str.Right(str.GetLength() - 2);
		m_list_msg.AddString(str);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
	}


	else if (check == "최종") {
		//MessageBox(L"최종", L"");
		PlaySound(L"wav\\BGM_VOTE.wav", 0, SND_ASYNC | SND_LOOP); // 무한

		if (!death) {
			str = str.Right(str.GetLength() - 3);
			m_time = _ttoi(str.Left(2));
			str = str.Right(str.GetLength() - 3);
			m_list_msg.AddString(str);
			m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
			SetTimer(6, 3000, NULL);
		}
	}


//	else if (check == "방장") {
//	}

	else if (check == "프로") {//프로;;;;;누가 보냈나(0~7)_프로필정보(eye_mouth_...)
		CClientDC dc(this);
		CString item_info, who, item1, item2, item3, item4;
		CImage m_background;
		AfxExtractSubString(item_info, str, 5, ';');
		AfxExtractSubString(who, item_info, 0, '_');
		AfxExtractSubString(item1, item_info, 1, '_');
		AfxExtractSubString(item2, item_info, 2, '_');
		AfxExtractSubString(item3, item_info, 3, '_');
		AfxExtractSubString(item4, item_info, 4, '_');
		int who_i = _ttoi(who);
		item[who_i][0] = _ttoi(item1);
		item[who_i][1] = _ttoi(item2);
		item[who_i][2] = _ttoi(item3);
		item[who_i][3] = _ttoi(item4);
		Invalidate();
	}

	else {   //if (check == "진행") {
		CString out, tmp;
		/*check = str.Left(2);  //잘못 들어온 경우
			if (check == "지령" || check == "대화" || check == "시작" || check == "일몰") {
				str = str.Right(str.GetLength() - 2);
		}*/

		if (str != L"") {  //else if (str != L"") {
			m_list_msg.InsertString(-1, str);  //AfxExtractSubString(out, str, 0, '_');
			m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
		}
	}

	return 0;
}


void CMafiaLiarClientView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if ((drawuser == mynum) && mouseon) {
		drawnow = (float)timeGetTime() * 0.001f;
		if (drawnow - drawstt >= 0.1f) {
			if (point.x < rc.left) point.x = rc.left;
			else if (point.x > rc.right) point.x = rc.right;
			if (point.y < rc.top) point.y = rc.top;
			else if (point.y > rc.bottom) point.y = rc.bottom;

			CString str;

			if (sec == 0 || cnt >= 999) {
				OnLButtonUp(nFlags, point);
			}

			str.Format(L"좌표%04d%04d", point.x, point.y);
			m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);

			InvalidateRect(rc);
			
			drawstt = (float)timeGetTime() * 0.001f;
		}
		
	}

	CFormView::OnMouseMove(nFlags, point);
}


void CMafiaLiarClientView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (drawuser == mynum) {
		if (point.x > rc.left && point.x < rc.right && point.y > rc.top && point.y < rc.bottom) {
			mouseon = 1;

			CString str;
			str.Format(L"좌표%04d%04d", point.x, point.y);
			m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);

			InvalidateRect(rc);
			drawstt = (float)timeGetTime() * 0.001f;
		}
	}
	CFormView::OnLButtonDown(nFlags, point);
}


void CMafiaLiarClientView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if ((drawuser == mynum) && mouseon) {
		mouseon = 0;

		CString str;
		str.Format(L"마감");
		m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);

		KillTimer(0);
		InvalidateRect(rc);

		/*KillTimer(0);
		mouseon = 0;
		int draw = drawuser;
		drawuser = 0; // 스케치 종료
		//complete.Format(L"[%s]: 어때요? 나 시민 맞죠?", (LPCTSTR)username[draw - 1]);

		cnt = -1;
		complete.Format(L"");
		InvalidateRect(rc);
		//sec = 8;

		//GetDlgItem(IDC_STATIC1)->SetWindowTextW((LPCTSTR)str);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_LIST1)->ShowWindow(SW_SHOW);*/


		/*GetDlgItem(IDC_STATIC1)->SetWindowTextW((LPCTSTR)str);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_LIST1)->ShowWindow(SW_SHOW);

		cnt = -1;
		complete.Format(L"");

		InvalidateRect(rc);*/
	}
	CFormView::OnLButtonUp(nFlags, point);
}


void CMafiaLiarClientView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	CString str;

	if (nIDEvent == 0) {
		if (drawstr % 3 == 1) {
			complete.Format(L"\n[%s]님이 그리고 있습니다.                                                   (한붓그리기)", (LPCTSTR)username[drawuser - 1]);
		}
		else if (drawstr % 3 == 2) {
			complete.Format(L"\n[%s]님이 그리고 있습니다..                                                  (한붓그리기)", (LPCTSTR)username[drawuser - 1]);
		}
		else {
			complete.Format(L"\n[%s]님이 그리고 있습니다...                                                 (한붓그리기)", (LPCTSTR)username[drawuser - 1]);
			drawstr = 0;
		}

		str.Format(L"%02d:%02d", sec / 60, sec % 60);
		GetDlgItem(IDC_STATIC1)->SetWindowTextW((LPCTSTR)str);

		++drawstr;
		--sec; // 1초씩 감소

		InvalidateRect(rc);
		if (sec < 0) {
			KillTimer(0);
			//str.Format(L"마감");
			//m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);
			mouseon = 0;

			//SetTimer(6, 2000, NULL);  //투표버튼 보이기
		}
		
	}
	else if (nIDEvent == 1) {

		str.Format(L"%02d:%02d", sec / 60, sec % 60);
		GetDlgItem(IDC_STATIC1)->SetWindowTextW((LPCTSTR)str);

		--sec; // 1초씩 감소

		if (sec < 0) {
			KillTimer(1);
			GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_LIST1)->ShowWindow(SW_SHOW);

			cnt = -1;
			complete.Format(L"");

			InvalidateRect(rc);
			//KillTimer(1);
			SetTimer(7, 1000, NULL);
		}
		//InvalidateRect(rc);
	}

	else if (nIDEvent == 2) {

		if (sec < 0) {
			KillTimer(2);
		}
	}

	else if (nIDEvent == 3) {  //2->3 바꾸기!!!
		KillTimer(2);
		/*GetDlgItem(IDC_EDIT8)->ShowWindow(SW_HIDE);
		SetDlgItemText(IDC_EDIT8, L"");
		GetDlgItem(IDC_EDIT8)->EnableWindow(FALSE);
		SetDlgItemText(IDC_STATIC3, out);*/
		/*GetDlgItem(IDC_EDIT6)->ShowWindow(SW_HIDE);IDC_STATIC
		//GetDlgItem(IDC_EDIT6)->EnableWindow(FALSE);IDC_STATIC
		GetDlgItem(IDC_EDIT7)->ShowWindow(SW_HIDE);
		//GetDlgItem(IDC_EDIT7)->EnableWindow(FALSE);*/
		GetDlgItem(IDC_STATIC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC4)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC3)->ShowWindow(SW_SHOW);
	}

	else if (nIDEvent == 4) {  //대화 종료
		str.Format(L"00:%02d", m_time--);
		//GetDlgItem(IDC_STATIC1)->SetWindowTextW((LPCTSTR)str);
		GetDlgItem(IDC_STATIC1)->SetWindowTextW(str);

		if (m_time < 0) {
			KillTimer(4);
			str.Format(L"종료");
			//if(낮) 낮 이미지
			//else(밤) 밤 이미지

			if (m_case == 1) {  //대화 종료
				GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);
				disableAllSel();
				//str.Format(L"종료");
				//tover = tover + L"종료;";
			}
			else if (m_case == 2) {  //일몰 종료
				disableAllSel();
				//str.Format(L"종료");
			}
			else if (m_case == 3) {  //투표 종료
				PlaySound(NULL, AfxGetInstanceHandle(), NULL);
				disableAllSel();
				//str.Format(L"");
			}
			m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);
			m_case = 0;
		}
	}

	else if (nIDEvent == 5) {
		KillTimer(5);
		//mouseon = true;
		str.Format(L"연재%d%d", mynum, tmp_item[2]);
		m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);
		GetDlgItem(IDC_STATIC)->ShowWindow(SW_HIDE);
	}

	else if (nIDEvent == 6) {  //투표 버튼 띄우기
		KillTimer(6);
		//MessageBox(L"timer6", L"");
		if ((role[mynum - 1] != 33) && (mynum - 1 != selected)) {
			GetDlgItem(IDC_BUTTON17)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON18)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON17)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BUTTON18)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_BUTTON17)->ModifyStyle(0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);
			GetDlgItem(IDC_BUTTON18)->ModifyStyle(0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);
			GetDlgItem(IDC_LIST1)->ModifyStyle(0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);
			GetDlgItem(IDC_BUTTON17)->BringWindowToTop();
			GetDlgItem(IDC_BUTTON18)->BringWindowToTop();
		}
		//m_case = 0;
		//m_case = 4;
		SetTimer(8, 1000, NULL);
	}

	else if (nIDEvent == 7) { //그림그리기 끝난후
		KillTimer(7);
		str.Format(L"종료");
		m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);
	}

	else if (nIDEvent == 8) {  //최종투표중
		str.Format(L"00:%02d", m_time--);
		GetDlgItem(IDC_STATIC1)->SetWindowTextW(str);
		if (m_time < 0) {
			KillTimer(8);
			str.Format(L"종료");
			m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);
		}
	}

	/*else if (nIDEvent == 5) {  //대화 종료
		str.Format(L"00:%02d", --m_time);
		//GetDlgItem(IDC_STATIC1)->SetWindowTextW((LPCTSTR)str);
		GetDlgItem(IDC_STATIC1)->SetWindowTextW(str);

		if (m_time == 0) {
			KillTimer(5);
			//if(낮) 낮 이미지
			//else(밤) 밤 이미지
			disableAllSel();
			str.Format(L"종료");
			//tover = tover + L"종료;";
			m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);
		}
	}

	else if (nIDEvent == 6) {  //일몰 종료
		str.Format(L"00:%02d", --m_time);
		//GetDlgItem(IDC_STATIC1)->SetWindowTextW((LPCTSTR)str);
		GetDlgItem(IDC_STATIC1)->SetWindowTextW(str);

		if (m_time == 0) {
			KillTimer(6);
			//if(낮) 낮 이미지
			//else(밤) 밤 이미지
			disableAllSel();
			str.Format(L"종료");
			m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);
		}
	}*/

	CFormView::OnTimer(nIDEvent);
}

BOOL CMafiaLiarClientView::OnEraseBkgnd(CDC* pDC)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	CClientDC dc(this);
	CImage m_background;
	CDC memDC;
	CBitmap Bitmap, * oldBitmap;

	memDC.CreateCompatibleDC(&dc);
	Bitmap.CreateCompatibleBitmap(&dc, rc2.Width() - 5, rc2.Height() - 5);
	oldBitmap = memDC.SelectObject(&Bitmap);
	memDC.PatBlt(0, 0, rc.Width(), rc.Height(), BLACKNESS);

	int morn = 0; // 0 아침, 1 밤
	if (!morn)
		m_background.Load(L"BgMorning3.PNG");
	else
		m_background.Load(L"BgNight.PNG");

	m_background.Draw(memDC, 0, 0);
	m_background.Destroy();

	CBrush bs(RGB(51, 51, 51)), bs2;
	CPen pn;
	bs2.CreateStockObject(NULL_BRUSH);
	pn.CreatePen(PS_SOLID, 5, RGB(180, 180, 180));

	for (int i = 0; i < us_c; i++) {
		memDC.SelectObject(&bs);
		memDC.Rectangle(imagex[i] - 38, imagey[i], imagex[i] + 125, imagey[i] + 90);
		m_background.Load(itemselect3[item[i][2]]);
		m_background.Draw(memDC, imagex[i], imagey[i]);
		m_background.Destroy();
		m_background.Load(itemselect1[item[i][0]]);
		m_background.Draw(memDC, imagex[i], imagey[i]);
		m_background.Destroy();
		m_background.Load(itemselect2[item[i][1]]);
		m_background.Draw(memDC, imagex[i], imagey[i]);
		m_background.Destroy();
		m_background.Load(itemselect4[item[i][3]]);
		m_background.Draw(memDC, imagex[i], imagey[i]);
		m_background.Destroy();
	}
	memDC.SelectObject(&pn);
	memDC.SelectObject(&bs2);
	memDC.Rectangle(imagex[mynum-1] - 38, imagey[mynum - 1], imagex[mynum - 1] + 125, imagey[mynum - 1] + 90);
	
	dc.BitBlt(0, 0, rc2.Width(), rc2.Height(), &memDC, 0, 0, SRCCOPY);
	memDC.SelectObject(oldBitmap);
	memDC.DeleteDC();

	if (mouseon) {
		return FALSE;
	}
	else {
		return CFormView::OnEraseBkgnd(pDC);
	}
	//return CFormView::OnEraseBkgnd(pDC);
}


void CMafiaLiarClientView::OnDraw(CDC* /*pDC*/)
{
	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
	
	if (drawuser || cnt > -1) {
		CClientDC dc2(GetDlgItem(IDC_STATIC2));
		CDC memDC2;
		CBitmap Bitmap, * oldBitmap;

		memDC2.CreateCompatibleDC(&dc2);
		Bitmap.CreateCompatibleBitmap(&dc2, rc.Width() - 5, rc.Height() - 5);
		oldBitmap = memDC2.SelectObject(&Bitmap);
		memDC2.PatBlt(0, 0, rc.Width(), rc.Height(), BLACKNESS);

		CPen pen, * oldpen;
		pen.CreatePen(PS_INSIDEFRAME, 3, colors[usercolor]);
		oldpen = memDC2.SelectObject(&pen);

		memDC2.MoveTo(pt[0].x - rc.left, pt[0].y - rc.top);
		for (int i = 0; i <= cnt; i++)
			memDC2.LineTo(pt[i].x - rc.left, pt[i].y - rc.top);

		CFont s_font;
		s_font.CreateFont(15, 6, 0, 0, FW_HEAVY, FALSE, FALSE, FALSE,
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY, DEFAULT_PITCH, _T("맑은고딕"));
		memDC2.SelectObject(s_font);
		memDC2.SetBkMode(TRANSPARENT);
		memDC2.SetTextColor(RGB(200, 200, 200));
		memDC2.TextOutW(10, 10, complete);
		s_font.DeleteObject();

		memDC2.SelectObject(oldpen);
		pen.DeleteObject();

		dc2.BitBlt(0, 0, rc.Width(), rc.Height(), &memDC2, 0, 0, SRCCOPY);
		memDC2.SelectObject(oldBitmap);
		memDC2.DeleteDC();
	}
}


BOOL CMafiaLiarClientView::PreTranslateMessage(MSG* pMsg)
{
	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
	if (!drawuser && (pMsg->message == WM_KEYDOWN) && (pMsg->wParam == VK_RETURN)) {
		OnBnClickedBtnSend();
		return true;
	}

	return CFormView::PreTranslateMessage(pMsg);
}


void CMafiaLiarClientView::OnSize(UINT nType, int cx, int cy)
{
	CFormView::OnSize(nType, cx, cy);

	// TODO: 여기에 메시지 처리기 코드를 추가합니다.
	win_right = cx;
	win_bottom = cy;
}


void CMafiaLiarClientView::OnBnClickedButtonP1() // 잠깐 빌립니다, 쉿 테스트 중
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
//	CString str;
//	str.Format(L"연재%d%s", mynum/*선택된 사람 번호*/, (LPCTSTR)item[2]);
//	m_ClientSocket.Send((LPVOID)(LPCTSTR)str, str.GetLength() * 2);
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	if (mynum == 1)
		MessageBox(L"자기 자신은 선택할 수 없습니다.", L"알림");
	else {
		mySel = 1;
		tmp.Format(L"___________________[user%d]를 선택하였습니다.___________________", mySel);
		//m_list_msg.InsertString(-1, tmp);
		m_list_msg.AddString(tmp);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
		disableAllSel();
		sunset();
	}
}


HBRUSH CMafiaLiarClientView::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  여기서 DC의 특성을 변경합니다.
	int nCtlID = pWnd->GetDlgCtrlID();

	//pDC->SetBkMode(TRANSPARENT);
	switch (nCtlID) {
	case IDC_LIST1:
		pDC->SetBkColor(RGB(20, 20, 20));
		pDC->SetTextColor(RGB(250, 250, 250));
		hbr = ::CreateSolidBrush(RGB(51, 51, 51));
		break;
	case IDC_EDIT1:
		pDC->SetBkColor(RGB(51, 51, 51));
		pDC->SetTextColor(RGB(250, 250, 250));
		hbr = ::CreateSolidBrush(RGB(51, 51, 51));
		break;
	case IDC_STATIC1: case IDC_STATIC3: case IDC_STATIC4:
		pDC->SetBkColor(RGB(51, 51, 51));
		pDC->SetTextColor(RGB(255, 51, 51));
		hbr = ::CreateSolidBrush(RGB(51, 51, 51));
		break;
	case IDC_COMBO1:
		pDC->SetBkColor(RGB(51, 51, 51));
		pDC->SetTextColor(RGB(250, 250, 250));
		hbr = ::CreateSolidBrush(RGB(51, 51, 51));
		break;
	case IDC_STATIC:
		pDC->SetBkColor(RGB(25, 25, 25));
		pDC->SetTextColor(RGB(255, 25, 25));
		hbr = ::CreateSolidBrush(RGB(25, 25, 25));
		break;
	case IDC_STATIC_DTH:
		pDC->SetBkColor(RGB(255, 10, 10));  // ?
		pDC->SetTextColor(RGB(10, 10, 10));
		hbr = ::CreateSolidBrush(RGB(255, 10, 10));
		break;
	//default:
	//	break;
	}

	// TODO:  기본값이 적당하지 않으면 다른 브러시를 반환합니다.
	return hbr;
}


void CMafiaLiarClientView::OnBnClickedButtonP2()
{
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	if (mynum == 2)
		MessageBox(L"자기 자신은 선택할 수 없습니다.", L"알림");
	else {
		mySel = 2;
		tmp.Format(L"___________________[user%d]를 선택하였습니다.___________________", mySel);
		//m_list_msg.InsertString(-1, tmp);
		m_list_msg.AddString(tmp);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
		disableAllSel();
		sunset();
	}
}


void CMafiaLiarClientView::OnBnClickedButtonP3()
{
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	if (mynum == 3)
		MessageBox(L"자기 자신은 선택할 수 없습니다.", L"알림");
	else {
		mySel = 3;
		tmp.Format(L"___________________[user%d]를 선택하였습니다.___________________", mySel);
		m_list_msg.AddString(tmp);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
		disableAllSel();
		sunset();
	}
}


void CMafiaLiarClientView::OnBnClickedButtonP4()
{
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	if (mynum == 4)
		MessageBox(L"자기 자신은 선택할 수 없습니다.", L"알림");
	else {
		mySel = 4;
		tmp.Format(L"___________________[user%d]를 선택하였습니다.___________________", mySel);
		m_list_msg.AddString(tmp);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
		disableAllSel();
		sunset();
	}
}


void CMafiaLiarClientView::OnBnClickedButtonP5()
{
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	if (mynum == 5)
		MessageBox(L"자기 자신은 선택할 수 없습니다.", L"알림");
	else {
		mySel = 5;
		tmp.Format(L"___________________[user%d]를 선택하였습니다.___________________", mySel);
		m_list_msg.AddString(tmp);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
		disableAllSel();
		sunset();
	}
}


void CMafiaLiarClientView::OnBnClickedButtonP6()
{
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	if (mynum == 6)
		MessageBox(L"자기 자신은 선택할 수 없습니다.", L"알림");
	else {
		mySel = 6;
		tmp.Format(L"___________________[user%d]를 선택하였습니다.___________________", mySel);
		m_list_msg.AddString(tmp);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
		//disableAllSel();  //#####
		//sunset();  //#####
	}
}


void CMafiaLiarClientView::OnBnClickedButtonP7()
{
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	if (mynum == 7)
		MessageBox(L"자기 자신은 선택할 수 없습니다.", L"알림");
	else {
		mySel = 7;
		tmp.Format(L"___________________[user%d]를 선택하였습니다.___________________", mySel);
		m_list_msg.AddString(tmp);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
		disableAllSel();
		sunset();
	}
}


void CMafiaLiarClientView::OnBnClickedButtonP8()
{
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	if (mynum == 8)
		MessageBox(L"자기 자신은 선택할 수 없습니다.", L"알림");
	else {
		mySel = 8;
		tmp.Format(L"___________________[user%d]를 선택하였습니다.___________________", mySel);
		m_list_msg.AddString(tmp);
		m_list_msg.SetCurSel(m_list_msg.GetCount() - 1);
		disableAllSel();
		sunset();
	}
}


void CMafiaLiarClientView::enableAllSel()
{
	// TODO: 여기에 구현 코드 추가.
	/*switch (us_c) {
	case 8:
		GetDlgItem(IDC_BUTTON15)->EnableWindow(TRUE);
	//case 7:
		GetDlgItem(IDC_BUTTON14)->EnableWindow(TRUE);
	//case 6:
		GetDlgItem(IDC_BUTTON8)->EnableWindow(TRUE);
	//case 5:
		GetDlgItem(IDC_BUTTON13)->EnableWindow(TRUE);*/
		//case 4:
	GetDlgItem(IDC_BUTTON12)->EnableWindow(TRUE);
	//case 3:
	GetDlgItem(IDC_BUTTON11)->EnableWindow(TRUE);
	//case 2:
	GetDlgItem(IDC_BUTTON3)->EnableWindow(TRUE);
	//case 1:
	GetDlgItem(IDC_BUTTON2)->EnableWindow(TRUE);
	//	break;
	//}
}


void CMafiaLiarClientView::disableAllSel()
{
	// TODO: 여기에 구현 코드 추가.
	GetDlgItem(IDC_BUTTON2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON3)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON11)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON12)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON13)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON8)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON14)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON15)->EnableWindow(FALSE);
}



void CMafiaLiarClientView::ctrlButton(int i, int u)
{
	// TODO: 여기에 구현 코드 추가.
	CString tmp(L"-");

	// 버튼 캡션
	if (i == 0) {
		switch (u) {
		case 1:
			SetDlgItemText(IDC_BUTTON2, tmp);
			break;
		case 2:
			SetDlgItemText(IDC_BUTTON3, tmp);
			break;
		case 3:
			SetDlgItemText(IDC_BUTTON11, tmp);
			break;
		case 4:
			SetDlgItemText(IDC_BUTTON12, tmp);
			break;
		case 5:
			SetDlgItemText(IDC_BUTTON13, tmp);
			break;
		case 6:
			SetDlgItemText(IDC_BUTTON8, tmp);
			break;
		case 7:
			SetDlgItemText(IDC_BUTTON14, tmp);
			break;
		case 8:
			SetDlgItemText(IDC_BUTTON15, tmp);
		}
	}

	// 버튼 비활성화
	//else if (i == 1) {
		
	//}
}


void CMafiaLiarClientView::sunset()
{
	// TODO: 여기에 구현 코드 추가.
	CString tmp;
	tmp.Format(L"일몰%d;%d;", mynum, mySel);
	m_ClientSocket.Send((LPVOID)(LPCTSTR)tmp, tmp.GetLength() * 2);
	mySel = -1;
}


void CMafiaLiarClientView::OnBnClickedStartGame()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	tmp.Format(L"방장");
	m_ClientSocket.Send((LPVOID)(LPCTSTR)tmp, tmp.GetLength() * 2);
	GetDlgItem(IDC_BUTTON16)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BUTTON16)->EnableWindow(FALSE);
	MessageBox(L"1", L"");
}


void CMafiaLiarClientView::OnBnClickedBtnYES()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	tmp.Format(L"결과;Y");
	m_ClientSocket.Send((LPVOID)(LPCTSTR)tmp, tmp.GetLength() * 2);
	GetDlgItem(IDC_BUTTON17)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BUTTON17)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON18)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BUTTON18)->EnableWindow(FALSE);
}


void CMafiaLiarClientView::OnBnClickedBtnNO()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	CString tmp;
	tmp.Format(L"결과;N");
	m_ClientSocket.Send((LPVOID)(LPCTSTR)tmp, tmp.GetLength() * 2);
	GetDlgItem(IDC_BUTTON17)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BUTTON17)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON18)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_BUTTON18)->EnableWindow(FALSE);
}
