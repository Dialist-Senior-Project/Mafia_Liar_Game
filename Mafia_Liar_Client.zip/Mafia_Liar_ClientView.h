﻿
// Mafia_Liar_ClientView.h: CMafiaLiarClientView 클래스의 인터페이스
//

#pragma once

#include "CClientSocket.h"
#include "GameStart.h"
#include "Profile.h"

#pragma comment(lib, "winmm.lib")
#include <mmsystem.h>

class CMafiaLiarClientView : public CFormView
{
protected: // serialization에서만 만들어집니다.
	CMafiaLiarClientView() noexcept;
	DECLARE_DYNCREATE(CMafiaLiarClientView)

public:
#ifdef AFX_DESIGN_TIME
	enum{ IDD = IDD_MAFIA_LIAR_CLIENT_FORM };
#endif

// 특성입니다.
public:
	CMafiaLiarClientDoc* GetDocument() const;

// 작업입니다.
public:

// 재정의입니다.
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.
	virtual void OnInitialUpdate(); // 생성 후 처음 호출되었습니다.
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);

// 구현입니다.
public:
	virtual ~CMafiaLiarClientView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 생성된 메시지 맵 함수
protected:
	DECLARE_MESSAGE_MAP()
private:
	CClientSocket m_ClientSocket;
public:
	CListBox m_list_msg;
	CEdit m_edit_send;
	afx_msg void OnBnClickedBtnSend();
protected:
	afx_msg LRESULT OnClientRecv(WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual void OnDraw(CDC* /*pDC*/);
	int cnt; // 그리기
	int mouseon; // 그리기
	CPoint pt[1000]; // 그리기
	int sec; // 타이머 시간
	CString complete; // 문자열 출력
	CBrush m_brush;
	CComboBox m_combo1;
	CComboBox m_combo2;
	CComboBox m_combo3;
	CComboBox m_combo4;
	CComboBox m_combo5;
	CComboBox m_combo6;
	CComboBox m_combo7;
	CComboBox m_combo8;
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CRect rc, rc2;
	int win_right, win_bottom;
	int drawuser;
	int usercolor;
	float drawstt, drawnow;
	int drawstr;

	// 파, 초, 주, 분, 빨, 민, 보, 하, 노
	COLORREF colors[9] = { RGB(102,102,255), RGB(51,204,51), RGB(255,153,0), RGB(255,153,203), 
		RGB(255,51,0), RGB(102,255,204), RGB(204,102,255), RGB(250,250,250), RGB(255,230,51) };

	int item[8][4];
	CString username[8];
	CString userPort[8];
	CString userClient[8];
	int c_count;
	int us_c;
	int usernameprint[8];
	CString profileOK;
	int mynum;
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBnClickedButtonP1();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	int imagex[8];
	int imagey[8];
	int imageok[8];
	int tmp_item[4];
	CString itemRev;
	CString itemselect1[6] = { L"EyeDot.PNG", L"EyeEye.PNG", L"EyeSharp.PNG", L"EyeSmile.PNG", L"EyeWink.PNG", L"EyeWWink.PNG" };
	CString itemselect2[6] = { L"M_.PNG", L"MBad.PNG", L"MOpen.PNG", L"MRect.PNG", L"MSmile.PNG", L"MSuck.PNG" };
	CString itemselect3[9] = { L"Blue.PNG", L"Green.PNG", L"Orange.PNG", L"Pink.PNG", L"Red.PNG", L"Skyblue.PNG", L"Violet.PNG", L"White.PNG", L"Yellow.PNG" };
	CString itemselect4[9] = { L"Dr.PNG", L"Glasses.PNG", L"Gun.PNG", L"Hat.PNG", L"Necktie.PNG", L"Ribon.PNG", L"Ribon2.PNG", L"Wanjang.PNG", L"Whistle.PNG" };

	int role[8];
	int mySel, m_time, m_case, selected;
	CString out, cwrd;
	bool death;
	afx_msg void OnBnClickedButtonP2();
	afx_msg void OnBnClickedButtonP3();
	afx_msg void OnBnClickedButtonP4();
	afx_msg void OnBnClickedButtonP5();
	afx_msg void OnBnClickedButtonP6();
	afx_msg void OnBnClickedButtonP7();
	afx_msg void OnBnClickedButtonP8();
	void enableAllSel();
	void disableAllSel();
	void ctrlButton(int i, int u);
	void sunset();
	afx_msg void OnBnClickedStartGame();
	afx_msg void OnBnClickedBtnYES();
	afx_msg void OnBnClickedBtnNO();
	CBitmapButton m_submit;
	
	CString userIP;
	CBitmapButton m_user1;
	CBitmapButton m_user2;
	CBitmapButton m_user3;
	CBitmapButton m_user4;
	CBitmapButton m_user5;
	CBitmapButton m_user6;
	CBitmapButton m_user7;
	CBitmapButton m_user8;
	CBitmapButton m_stt;
	CBitmapButton m_yes;
	CBitmapButton m_no;
};

#ifndef _DEBUG  // Mafia_Liar_ClientView.cpp의 디버그 버전
inline CMafiaLiarClientDoc* CMafiaLiarClientView::GetDocument() const
   { return reinterpret_cast<CMafiaLiarClientDoc*>(m_pDocument); }
#endif

