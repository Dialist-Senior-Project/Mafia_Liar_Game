﻿// Profile.cpp: 구현 파일
//

#include "pch.h"
#include "Mafia_Liar_Client.h"
#include "Profile.h"
//#include "afxdialogex.h"
#include "Mafia_Liar_ClientDoc.h"
#include "Mafia_Liar_ClientView.h"

#include <Mmsystem.h>
#pragma comment(lib, "Winmm.lib")

// Profile 대화 상자

IMPLEMENT_DYNAMIC(Profile, CDialogEx)

Profile::Profile(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_Profile, pParent)
{
}

Profile::~Profile()
{
}

void Profile::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON1, m_btn1);
	DDX_Control(pDX, IDC_BUTTON2, m_btn2);
	DDX_Control(pDX, IDC_BUTTON3, m_btn3);
	DDX_Control(pDX, IDC_BUTTON4, m_btn4);
	DDX_Control(pDX, IDC_BUTTON5, m_btn5);
	DDX_Control(pDX, IDC_BUTTON6, m_btn6);
}


BEGIN_MESSAGE_MAP(Profile, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &Profile::OnBnEye)
	ON_BN_CLICKED(IDC_BUTTON2, &Profile::OnBnMouth)
	ON_BN_CLICKED(IDC_BUTTON3, &Profile::OnBnColor)
	ON_BN_CLICKED(IDC_BUTTON4, &Profile::OnBnAccessory)
	ON_STN_CLICKED(IDC_item1, &Profile::OnStnItem1)
	ON_STN_CLICKED(IDC_item2, &Profile::OnStnItem2)
	ON_STN_CLICKED(IDC_item3, &Profile::OnStnItem3)
	ON_STN_CLICKED(IDC_item4, &Profile::OnStnItem4)
	ON_STN_CLICKED(IDC_item5, &Profile::OnStnItem5)
	ON_STN_CLICKED(IDC_item6, &Profile::OnStnItem6)
	ON_STN_CLICKED(IDC_item7, &Profile::OnStnItem7)
	ON_STN_CLICKED(IDC_item8, &Profile::OnStnItem8)
	ON_STN_CLICKED(IDC_item9, &Profile::OnStnItem9)
	ON_BN_CLICKED(IDC_BUTTON5, &Profile::OnBnOK)
	ON_BN_CLICKED(IDC_BUTTON6, &Profile::OnBnCancel)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


// Profile 메시지 처리기


void Profile::OnBnEye()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	p_kind = 0;
	Invalidate();
}


void Profile::OnBnMouth()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	p_kind = 1;
	Invalidate();
}


void Profile::OnBnColor()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	p_kind = 2;
	Invalidate();
}


void Profile::OnBnAccessory()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	PlaySound(L"wav\\BGM_BTN.wav", AfxGetInstanceHandle(), SND_ASYNC);
	p_kind = 3;
	Invalidate();
}

void Profile::OnStnItem1()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	p_item[p_kind] = 0;
	Invalidate();
}


void Profile::OnStnItem2()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	p_item[p_kind] = 1;
	Invalidate();
}


void Profile::OnStnItem3()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	p_item[p_kind] = 2;
	Invalidate();
}


void Profile::OnStnItem4()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	p_item[p_kind] = 3;
	Invalidate();
}


void Profile::OnStnItem5()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	p_item[p_kind] = 4;
	Invalidate();
}


void Profile::OnStnItem6()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	p_item[p_kind] = 5;
	Invalidate();
}


void Profile::OnStnItem7()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	p_item[p_kind] = 6;
	Invalidate();
}


void Profile::OnStnItem8()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	p_item[p_kind] = 7;
	Invalidate();
}


void Profile::OnStnItem9()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	p_item[p_kind] = 8;
	Invalidate();
}


void Profile::OnBnOK()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	//userIP = _T("");
	//GetDlgItem(IDC_EDIT1)->GetWindowText(userIP);
	//if (userIP == "") {
	//	AfxMessageBox(L"연결을 위해 본인의 IP 주소를 입력해 주세요.");
	//	return;
	//}
	OnOK();
}


void Profile::OnBnCancel()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CDialogEx::OnCancel();
}


void Profile::OnPaint()
{
	CPaintDC dc(this); // device context for painting
					   // TODO: 여기에 메시지 처리기 코드를 추가합니다.
					   // 그리기 메시지에 대해서는 CDialogEx::OnPaint()을(를) 호출하지 마십시오.
	CImage m_picture;
	CPen pen, pen2;
	CDC memDC;
	CBitmap Bitmap, * oldBitmap;

	memDC.CreateCompatibleDC(&dc);
	Bitmap.CreateCompatibleBitmap(&dc, scr.Width(), scr.Height());
	oldBitmap = memDC.SelectObject(&Bitmap);
	memDC.PatBlt(0, 0, scr.Width(), scr.Height(), BLACKNESS);
	//CBrush bs, bs2, bs3(RGB(255, 255, 255));
	//CRect rc;

	//COLORREF bkcolor = GetSysColor(COLOR_3DFACE);
	//pen.CreateStockObject(bkcolor);
	//bs.CreateStockObject(bkcolor);
	//dc.Rectangle(0, 50, rc.right, rc.bottom);


	//pen2.CreatePen(PS_SOLID, 5, RGB(0, 0, 255));
	//bs2.CreateStockObject(NULL_BRUSH);
	//dc.SelectObject(&pen2);
	//dc.SelectObject(&bs2);

	//dc.Rectangle(0, 0, rc.right, rc.bottom);

	pen.CreateStockObject(BLACK_PEN);
	memDC.SelectObject(&pen);
	CBrush bs(RGB(10, 10, 10)), bs3(RGB(230, 230, 230));
	memDC.SelectObject(&bs);
	memDC.Rectangle(scr);
	
	memDC.SelectObject(&bs3);
	switch (p_kind) {
	case 0:
		//memDC.Rectangle(88, 8, 166, 40);
		//memDC.Rectangle(166, 8, 244, 40);
		//memDC.Rectangle(244, 8, 322, 40);

		memDC.SelectObject(&bs3);

		for (int i = 0; i < 6; i++) {
			memDC.Rectangle(rc[i]);
			m_picture.Load(itemselect1[i]);
			m_picture.Draw(memDC, rc[i].right - 90, rc[i].bottom - 80);
			m_picture.Destroy();
		}
		GetDlgItem(IDC_item7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_item8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_item9)->ShowWindow(SW_HIDE);
		break;
	case 1:
		//memDC.Rectangle(10, 8, 88, 40);
		//memDC.Rectangle(166, 8, 244, 40);
		//memDC.Rectangle(244, 8, 322, 40);

		memDC.SelectObject(&bs3);

		for (int i = 0; i < 6; i++) {
			memDC.Rectangle(rc[i]);
			m_picture.Load(itemselect2[i]);
			m_picture.Draw(memDC, rc[i].right- 90, rc[i].bottom- 80);
			m_picture.Destroy();
		}
		GetDlgItem(IDC_item7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_item8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_item9)->ShowWindow(SW_HIDE);
		break;
	case 2:
		//memDC.Rectangle(10, 8, 88, 40);
		//memDC.Rectangle(88, 8, 166, 40);
		//memDC.Rectangle(244, 8, 322, 40);

		memDC.SelectObject(&bs3);

		for (int i = 0; i < 9; i++) {
			memDC.Rectangle(rc[i]);
			m_picture.Load(itemselect3[i]);
			m_picture.Draw(memDC, rc[i].right - 90, rc[i].bottom - 80);
			m_picture.Destroy();
		}
		GetDlgItem(IDC_item7)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_item8)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_item9)->ShowWindow(SW_SHOW);
		break;
	case 3:
		//memDC.Rectangle(10, 8, 88, 40);
		//memDC.Rectangle(88, 8, 166, 40);
		//memDC.Rectangle(166, 8, 244, 40);

		memDC.SelectObject(&bs3);

		for (int i = 0; i < 9; i++) {
			memDC.Rectangle(rc[i]);
			m_picture.Load(itemselect4[i]);
			m_picture.Draw(memDC, rc[i].right - 90, rc[i].bottom - 80);
			m_picture.Destroy();
		}
		GetDlgItem(IDC_item7)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_item8)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_item9)->ShowWindow(SW_SHOW);
		break;
	}

	memDC.SelectObject(&bs3);
	memDC.Rectangle(rc[9]);

	m_picture.Load(itemselect3[p_item[2]]);
	m_picture.Draw(memDC, rc[9].right - 90, rc[9].bottom - 80);
	m_picture.Destroy();
	m_picture.Load(itemselect1[p_item[0]]);
	m_picture.Draw(memDC, rc[9].right - 90, rc[9].bottom - 80);
	m_picture.Destroy();
	m_picture.Load(itemselect2[p_item[1]]);
	m_picture.Draw(memDC, rc[9].right - 90, rc[9].bottom - 80);
	m_picture.Destroy();
	m_picture.Load(itemselect4[p_item[3]]);
	m_picture.Draw(memDC, rc[9].right - 90, rc[9].bottom - 80);
	m_picture.Destroy();

	dc.BitBlt(0, 0, scr.Width(), scr.Height(), &memDC, 0, 0, SRCCOPY);
	memDC.SelectObject(oldBitmap);
	memDC.DeleteDC();
}


BOOL Profile::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  여기에 추가 초기화 작업을 추가합니다.
	GetClientRect(&scr);

	GetDlgItem(IDC_item1)->GetWindowRect(&rc[0]);
	ScreenToClient(&rc[0]);
	GetDlgItem(IDC_item2)->GetWindowRect(&rc[1]);
	ScreenToClient(&rc[1]);
	GetDlgItem(IDC_item3)->GetWindowRect(&rc[2]);
	ScreenToClient(&rc[2]);
	GetDlgItem(IDC_item4)->GetWindowRect(&rc[3]);
	ScreenToClient(&rc[3]);
	GetDlgItem(IDC_item5)->GetWindowRect(&rc[4]);
	ScreenToClient(&rc[4]);
	GetDlgItem(IDC_item6)->GetWindowRect(&rc[5]);
	ScreenToClient(&rc[5]);
	GetDlgItem(IDC_item7)->GetWindowRect(&rc[6]);
	ScreenToClient(&rc[6]);
	GetDlgItem(IDC_item8)->GetWindowRect(&rc[7]);
	ScreenToClient(&rc[7]);
	GetDlgItem(IDC_item9)->GetWindowRect(&rc[8]);
	ScreenToClient(&rc[8]);
	GetDlgItem(IDC_STATIC)->GetWindowRect(&rc[9]);
	ScreenToClient(&rc[9]);

	m_btn1.LoadBitmaps(IDB_EYES1, IDB_EYES2, IDB_EYES2, NULL);
	m_btn1.SizeToContent();
	m_btn2.LoadBitmaps(IDB_LIPS1, IDB_LIPS2, IDB_LIPS2, NULL);
	m_btn2.SizeToContent();
	m_btn3.LoadBitmaps(IDB_COLORS1, IDB_COLORS2, IDB_COLORS2, NULL);
	m_btn3.SizeToContent();
	m_btn4.LoadBitmaps(IDB_PIT1, IDB_PIT2, IDB_PIT2, NULL);
	m_btn4.SizeToContent();
	m_btn5.LoadBitmaps(IDB_OK1, IDB_OK2, NULL, NULL);
	m_btn5.SizeToContent();
	m_btn6.LoadBitmaps(IDB_BACKMAIN1, IDB_BACKMAIN2, NULL, NULL);
	m_btn6.SizeToContent();

	return TRUE;  // return TRUE unless you set the focus to a control
				  // 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}


BOOL Profile::OnEraseBkgnd(CDC* pDC)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	return FALSE;
	//return CDialogEx::OnEraseBkgnd(pDC);
}