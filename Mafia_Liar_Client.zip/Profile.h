﻿#pragma once


// Profile 대화 상자

class Profile : public CDialogEx
{
	DECLARE_DYNAMIC(Profile)

public:
	Profile(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~Profile();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_Profile };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnEye();
	afx_msg void OnBnMouth();
	afx_msg void OnBnColor();
	afx_msg void OnBnAccessory();
	afx_msg void OnStnItem1();
	afx_msg void OnStnItem2();
	afx_msg void OnStnItem3();
	afx_msg void OnStnItem4();
	afx_msg void OnStnItem5();
	afx_msg void OnStnItem6();
	afx_msg void OnStnItem7();
	afx_msg void OnStnItem8();
	afx_msg void OnStnItem9();
	int p_kind;
	int p_item[4];
	afx_msg void OnBnOK();
	afx_msg void OnBnCancel();
	afx_msg void OnPaint();
	CRect rc[10], scr;

	CString itemselect1[6] = { L"EyeDot.PNG", L"EyeEye.PNG", L"EyeSharp.PNG", L"EyeSmile.PNG", L"EyeWink.PNG", L"EyeWWink.PNG" };
	CString itemselect2[6] = { L"M_.PNG", L"MBad.PNG", L"MOpen.PNG", L"MRect.PNG", L"MSmile.PNG", L"MSuck.PNG" };
	CString itemselect3[9] = { L"Blue.PNG", L"Green.PNG", L"Orange.PNG", L"Pink.PNG", L"Red.PNG", L"Skyblue.PNG", L"Violet.PNG", L"White.PNG", L"Yellow.PNG" };
	CString itemselect4[9] = { L"Dr.PNG", L"Glasses.PNG", L"Gun.PNG", L"Hat.PNG", L"Necktie.PNG", L"Ribon.PNG", L"Ribon2.PNG", L"Wanjang.PNG", L"Whistle.PNG" };
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	CBitmapButton m_btn1;
	CBitmapButton m_btn2;
	CBitmapButton m_btn3;
	CBitmapButton m_btn4;
	CBitmapButton m_btn5;
	CBitmapButton m_btn6;

	CString userIP;
};
